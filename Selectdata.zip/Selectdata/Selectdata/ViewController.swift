//
//  ViewController.swift
//  Selectdata
//
//  Created by MACOS on 6/19/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
var final = [Any]()
    
    @IBOutlet var tbl: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnSelect(_ sender: Any) {
        let str = String("http://localhost/test/select.php")
        
        let url = URL(string: str!)
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
            DispatchQueue.main.sync {
                
                do
                {
                    let dic = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    
                    for item in dic
                    {
                     
                        var arr : [String] = []
                        arr.append(item["Id"]! as! String)
                        arr.append(item["Name"]! as! String)
                        arr.append(item["Address"]! as! String)
                        
                        self.final.append(arr)
                        self.tbl.reloadData()
                        
                        print(self.final)
                        
                        
                     // Record in one by one in tableview
                     //  self.final.append(item)
                     //  self.tbl.reloadData()
                     //  print(self.final)
                    }
                }
                catch
                {
                    
                }
            }
            
         // let str1 = String(data: data1!, encoding: String.Encoding.utf8)
           // print(str1)
            
        })
        datatask.resume()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return final.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        // Section code
        
        let dic = final[indexPath.section] as! [String]
        cell.textLabel?.text = dic[indexPath.row]

        
        //Record in one by one in tableview
        //let dicfinal = final[indexPath.row] as![String:Any]
        //cell.textLabel?.text = dicfinal["Name"] as! String
        return cell
    }
    


}

